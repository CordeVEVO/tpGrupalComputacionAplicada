if [ "$1" == "-help" ]; then
    echo "Uso: backup_full.sh <origen> <destino>"
    echo "Ejemplo: backup_full.sh /var/log /backup_dir"
    exit 0
fi


if [ -z "$1" ] || [ -z "$2" ]; then
    echo "Error: debe indicar origen y destino"
    exit 1
fi


ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename $ORIGEN)


if [ ! -d "$ORIGEN" ]; then
    echo "Error: origen $ORIGEN no existe o no esta disponible"
    exit 1
fi


if [ ! -d "$DESTINO" ]; then
    echo "Error: destino $DESTINO no existe o no esta disponible"
    exit 1
fi


tar -czf "$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz" "$ORIGEN"


if [ $? -eq 0 ]; then
    echo "Backup exitoso: $DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"
else
    echo "Error al crear el backup"
    exit 1
fi
